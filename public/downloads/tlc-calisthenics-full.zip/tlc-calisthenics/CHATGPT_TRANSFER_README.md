# TLC Calisthenics — Full Transfer Pack

Everything needed to move this app to ChatGPT or any other tool.

- `src/` — full app source (React + TypeScript + Tailwind)
- `supabase/` — backend functions and database migrations (tables: workout_logs, user_roles)
- `exercise-library/exercises.json` — the complete exercise library as plain data
- `exercise-library/thumbnails/` — every video thumbnail + skill image (named by exercise id)

Run locally: `npm install` then `npm run dev`.
Tip for ChatGPT: upload this ZIP and say "Here is my app's full code and exercise library — help me continue building it."
